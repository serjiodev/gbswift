import UIKit
import Foundation



// 1 задание
// Написать функцию, которая определяет, четное число или нет.

var namberArray = [10, 14, 21, 54, 51, 98, 54, 33, 77, 88, 90];
for namberInt: Int in namberArray{
    if namberInt % 2 == 0 {
        print("\(namberInt) Это четное число")
    } else {
        print("\(namberInt) Это не четное число")
    }
}

// 2 задание
// Написать функцию, которая определяет, делится ли число без остатка на 3.

func threeNum(value: Int) {
    let num1 = value
    let num2 = num1%3
    _ = num2 == 0 ? print("true") : print("flase")
}

threeNum(value: 6)

// 3 задание
// Создать возрастающий массив из 100 чисел.

var array = [Int]()
var i = 0

while i < 100 {
    array.append(i+1)
    i += 1
}

// 4 задание
// Удалить из этого массива все четные числа и все числа, которые не делятся на 3.

for namber in array where (namber%2 == 0) || (namber%3 == 0){
    
    array.remove(at : (array.firstIndex(of: namber)!))
}
// 5 задание



// 6 задание
// Заполнить массив из 100 элементов различными простыми числами. Натуральное число, большее единицы, называется простым, если оно делится только на себя и на единицу. Для нахождения всех простых чисел не больше заданного числа n, следуя методу Эратосфена, нужно выполнить следующие шаги:

func fibNamber (num: Int) -> Bool {
    if num < 2 {
        return false
    }
    for i in 2..<num {
        if num % i == 0 {
            return false
        }
    }
    
    return true
}
func fibNamberArray () -> [Int] {
    var results = [Int]()
    var i = 2
    while results.count < 100 {
        if fibNamber(num: i) {
            results.append(i)
        }
        i += 1
    }
    
    return results
}
print (fibNamberArray())
